import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { COLORS } from '../utils/Consntants';

const CustomButton = (props) => {
    const {
        onPress,
        buttonLabel
    } = props;

    return (
        <Pressable
            onPress={onPress}
            style={({ pressed }) => [
                {
                    backgroundColor: pressed ? 'rgb(210, 230, 255)' : COLORS.DODGER_BLUE,
                },
                styles.wrapperCustom,
            ]}>
            {({ pressed }) => (
                <Text style={styles.text}>{buttonLabel}</Text>
            )}
        </Pressable>
    );
};

export const Button = React.memo(CustomButton);

const styles = StyleSheet.create({
    text: {
        fontSize: 16,
        fontWeight: 'bold',
        fontStyle: 'normal',
        color: COLORS.WHITE
    },
    wrapperCustom: {
        borderRadius: 5,
        padding: 10,
        alignItems: 'center',
        justifyContent: 'center',
        marginHorizontal: 15,
    },
});