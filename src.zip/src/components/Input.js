import React, { useEffect } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    Text,
    View,
    TextInput,
    Image
} from 'react-native';
import { COLORS } from '../utils/Consntants'

const CustomInput = (props) => {
    const { 
        onChangeText, 
        placeholder, 
        value, 
        inputLabel, 
        imgPath,
    } = props;
    return (
        <View style={styles.container}>
            <Text style={styles.inputLabel}>
                {inputLabel}
            </Text>
            <View style={styles.row}>
                <Image source={imgPath} style={{ height: 25, width: 25 }} />
                <TextInput
                    style={styles.input}
                    onChangeText={onChangeText}
                    value={value}
                    placeholder={placeholder}
                />
            </View>
        </View>
    )
}

export const Input = React.memo(CustomInput);

const styles = StyleSheet.create({
    input: {
        fontSize: 14,
        fontFamily: 'normal',
        fontWeight: '500',
        color: COLORS.BLACK,
        height: 40,
        padding: 10,
        flexGrow: 1,
        flex: 1,
    },
    inputLabel: {
        paddingLeft: 35
    },
    container: {
        borderWidth: 1,
        borderColor: COLORS.GRAY_DDD,
        margin: 15,

        paddingHorizontal: 5,
        borderRadius: 5,
        backgroundColor: COLORS.WHITE_F2
    },
    row: {
        flexDirection: 'row',
    },
    text: {
        fontSize: 14,
        fontFamily: 'normal',
        fontWeight: '500',
        color: COLORS.BLACK
    }
})