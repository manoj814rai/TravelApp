export const sagaActions = {
    FETCH_FLIGHT_DATA_SAGA: "FETCH_FLIGHT_DATA_SAGA"
};