
import React, { useEffect, useState } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    Text,
    View
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { sagaActions } from "../redux/saga/SagaActions.js";
import { setLoading } from '../redux/slices/FlightSlices'
import { Loader } from '../components/Loader';
import { COLORS } from '../utils/Consntants';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { FlightList } from '../components/FlightList';

const debounceFunc = (func, delay) => {
    let timer;
    return function (...args) {
        const context = this;
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(context, args);
        }, delay)
    }
}

const Home = () => {
    const dispatch = useDispatch();
    const { flightList, isLoading } = useSelector(state => state.fligthReducer);
    const [formData, setFormData] = useState({
        to: '',
        from: '',
        date: ''
    });
    const [selectedTo, setTo] = useState({});
    const [selectedFrom, setFrom] = useState({});
    const [filteredList, setFilterList] = useState([]);

    async function logJSONData() {
        const response = await fetch("http://example.com/movies.json");
        const jsonData = await response.json();
        console.log(jsonData);
      }

    useEffect(() => {
        // dispatch(setLoading(true));
        // dispatch({ type: sagaActions.FETCH_FLIGHT_DATA_SAGA });
        logJSONData();
    }, []);


    const onChangeText = (fieldName, value) => {
        const data = { ...formData };
        data[fieldName] = value;
        setFormData(data);
        filterFlight(flightList, value, fieldName);
    };

    const selectFlightItem = (selectedItem, type) => {
        console.log('selectFlightItem ---, ',selectedItem, type)
    };

    const filterFlight = (list, value, type) => {
        let updatedList = [], foundObj = null;
        if (type == "to") {
            foundObj = list.find(item => {
                console.log('item.displayData --', item.displayData?.destination?.airport?.cityName);
                return (item.displayData?.destination?.airport?.cityName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.destination?.airport?.airportName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.destination?.airport?.airportCode.toLowerCase().includes(value.toLowerCase())
                )
            }
            )
        }
        else {
            foundObj = list.find(item => {
                return item.displayData?.source?.airport?.cityName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.source?.airport?.airportName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.source?.airport?.airportCode.toLowerCase().includes(value.toLowerCase())
            }
            )
        }
        console.log('updatedList ----------', updatedList);
        if(foundObj) {
            updatedList.push(foundObj);
        }
        setFilterList(updatedList);
    }

    const onEndEditing = (fieldName, event) => {
        console.log('onEndEditing', fieldName, event);
    }

    return (
        <SafeAreaView style={styles.container}>
            <View style={{ flex: 1 }}>
                <HeaderComponent />
                {/* <Input
                    onChangeText={(text) => onChangeText("from", text)}
                    inputLabel={"From"}
                    imgPath={require('../assets/flight_takeoff.png')}
                    placeholder={"Enter source location"}
                />
                <Input
                    onChangeText={(text) => onChangeText("to", text)}
                    inputLabel={"To"}
                    imgPath={require('../assets/flight_land.png')}
                    placeholder={"Enter destination location"}
                />
                {filteredList.length ?
                    <View style={{ flex: 0.7, marginHorizontal: 15 }}>
                        <FlightList flightData={filteredList} selectFlightItem={selectFlightItem}/>
                    </View>
                    : null
                } */}
            </View>
            {/* <View style={{ paddingBottom: 20 }}>
                <Button
                    onPress={() => { }}
                    buttonLabel={"Search"}
                />
            </View> */}
        </SafeAreaView>
    )
};

const HeaderComponent = () => {
    return (
        <View style={styles.header}>
            <Text style={styles.welcomeLabel}>
                Welcome to Travel.com
            </Text>
        </View>
    )
}

const From = () => {

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.WHITE,
        justifyContent: 'space-between'
    },
    welcomeLabel: {
        fontSize: 24,
        fontFamily: 'normal',
        fontWeight: 'bold',
        color: COLORS.WHITE
    },
    header: {
        backgroundColor: COLORS.DODGER_BLUE,
        flex: 0.2,
        alignItems: 'center',
        justifyContent: 'center'
    }
});


export default Home;
