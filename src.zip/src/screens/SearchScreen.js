
import React, { useEffect, useState } from 'react';
import {
    SafeAreaView,
    StyleSheet,
    Text,
    View
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { sagaActions } from "../redux/saga/SagaActions.js";
import { setLoading } from '../redux/slices/FlightSlices'
import { Loader } from '../components/Loader';
import { COLORS } from '../utils/Consntants';
import { Input } from '../components/Input';
import { Button } from '../components/Button';
import { FlightList } from '../components/FlightList';

const debounceFunc = (func, delay) => {
    let timer;
    return function (...args) {
        const context = this;
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(context, args);
        }, delay)
    }
}

const Search = (props) => {
    const dispatch = useDispatch();
    const { flightList } = useSelector(state => state.fligthReducer);
    const [selectedFlightData, setFlightData] = useState({});
    const [filteredList, setFilterList] = useState([]);

    const onPressLike = (selectedItem) => {
    }

    const onChangeText = (fieldName, value) => {
        const data = { ...formData };
        data[fieldName] = value;
        setFormData(data);
        filterFlight(flightList, value, fieldName);
    };

    // useEffect(() => {
    //     filterFlight(flightList, value, fieldName);
    // }, [formData.to, formData.from])

    const selectFlightItem = (item) => {
        setFlightData(item);
        props.navigation.goBack();
    };

    const filterFlight = (list, value, type) => {
        let updatedList = [], foundObj = null;
        if (type == "to") {
            foundObj = list.find(item => {
                console.log('item.displayData --', item.displayData?.destination?.airport?.cityName);
                return (item.displayData?.destination?.airport?.cityName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.destination?.airport?.airportName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.destination?.airport?.airportCode.toLowerCase().includes(value.toLowerCase())
                )
            }
            )
        }
        else {
            foundObj = list.find(item => {
                return item.displayData?.source?.airport?.cityName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.source?.airport?.airportName.toLowerCase().includes(value.toLowerCase()) ||
                    item.displayData?.source?.airport?.airportCode.toLowerCase().includes(value.toLowerCase())
            }
            )
        }
        console.log('updatedList ----------', updatedList);
        if(foundObj) {
            updatedList.push(foundObj);
        }
        setFilterList(updatedList);
    }

    return (
        <SafeAreaView style={styles.container}>
            <View style={{ flex: 1 }}>
                <HeaderComponent />
                <Input
                    onChangeText={(text) => onChangeText("from", text)}
                    inputLabel={"From"}
                    imgPath={require('../assets/flight_takeoff.png')}
                    placeholder={"Enter source location"}
                />
                {filteredList.length ?
                    <View style={{ flex: 0.7, borderWidth: 1, borderColor: COLORS.GRAY_DDD, marginHorizontal: 15 }}>
                        <FlightList flightData={filteredList} />
                    </View>
                    : null
                }
            </View>
        </SafeAreaView>
    )
};

const HeaderComponent = () => {
    return (
        <View style={styles.header}>
            <Text style={styles.welcomeLabel}>
                Welcome to Travel.com
            </Text>
        </View>
    )
}

const From = () => {

}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: COLORS.WHITE,
        justifyContent: 'space-between'
    },
    welcomeLabel: {
        fontSize: 24,
        fontFamily: 'normal',
        fontWeight: 'bold',
        color: COLORS.WHITE
    },
    header: {
        backgroundColor: COLORS.DODGER_BLUE,
        flex: 0.2,
        alignItems: 'center',
        justifyContent: 'center'
    }
});


export default Home;
