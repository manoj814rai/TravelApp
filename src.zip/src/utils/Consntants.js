const COLORS = {
    DODGER_BLUE : '#1e90ff',
    WHITE: '#fff',
    BLACK: '#000',
    GRAY_DDD: '#ddd',
    WHITE_F2: '#f2f2f2'
}

export {
    COLORS
}